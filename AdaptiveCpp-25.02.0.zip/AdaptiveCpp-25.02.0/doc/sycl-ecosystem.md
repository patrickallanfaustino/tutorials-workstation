The following image illustrates how AdaptiveCpp fits into the wider SYCL implementation ecosystem:
<img src="img/sycl-targets.png" width=80% height=80%>